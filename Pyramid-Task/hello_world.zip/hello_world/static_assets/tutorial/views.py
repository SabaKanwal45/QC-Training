from pyramid.view import view_config


# First view, available at http://localhost:6543/
@view_config(route_name='add_book', renderer='add_book.pt')
def add_book(request):
    return {'name': 'Add Book View'}


# /howdy
@view_config(route_name='edit_book', renderer='edit_book.pt')
def edit_book(request):
    return {'name': 'Edit Book View'}


# /howdy
@view_config(route_name='delete_book', renderer='delete_book.pt')
def delete_book(request):
    return {'name': 'Delete Book View'}


# /howdy
@view_config(route_name='list_books', renderer='list_books.pt')
def list_books(request):
    return {'name': 'View List Of Books'}