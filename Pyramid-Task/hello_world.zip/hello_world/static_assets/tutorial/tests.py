import unittest

from pyramid import testing


class TutorialViewTests(unittest.TestCase):
    def setUp(self):
        self.config = testing.setUp()

    def tearDown(self):
        testing.tearDown()

    def test_add_book(self):
        from .views import add_book

        request = testing.DummyRequest()
        response = add_book(request)
        # Our view now returns data
        self.assertEqual('Add Book View', response['name'])

    def test_edit_book(self):
        from .views import edit_book

        request = testing.DummyRequest()
        response = edit_book(request)
        # Our view now returns data
        self.assertEqual('Edit Book View', response['name'])

    def test_delete_book(self):
        from .views import delete_book

        request = testing.DummyRequest()
        response = delete_book(request)
        # Our view now returns data
        self.assertEqual('Delete Book View', response['name'])

    def test_list_books(self):
        from .views import list_books

        request = testing.DummyRequest()
        response = list_books(request)
        # Our view now returns data
        self.assertEqual('View List Of Books', response['name'])


class TutorialFunctionalTests(unittest.TestCase):
    def setUp(self):
        from tutorial import main
        app = main({})
        from webtest import TestApp

        self.testapp = TestApp(app)

    def test_add_book(self):
        from .views import add_book
        res = self.testapp.get('/', status=200)
        #self.assertIn(add_book, res.body)

    def test_edit_book(self):
        res = self.testapp.get('/edit_book', status=200)
        #self.assertIn(b'<h1>Hi Hello View', res.body)