from pyramid.security import Allow, Everyone

from sqlalchemy import (
    Column,
    Integer,
    Text,
    )

from sqlalchemy.ext.declarative import declarative_base

from sqlalchemy.orm import (
    scoped_session,
    sessionmaker,
    )

from zope.sqlalchemy import ZopeTransactionExtension

DBSession = scoped_session(
    sessionmaker(extension=ZopeTransactionExtension()))
Base = declarative_base()


class Page(Base):
    """
    Create table named books in database Book_Store
    """
    __tablename__ = 'books'
    book_id = Column(Integer, primary_key=True)
    book_title = Column(Text)
    book_author = Column(Text)
    book_edition = Column(Integer)
    book_price = Column(Integer)
    book_quantity = Column(Integer)


class Root(object):
    __acl__ = [(Allow, Everyone, 'view'),
               (Allow, 'group:editors', 'edit')]

    def __init__(self, request):
        pass
