"""
Book Store Views
"""
import colander
import deform.widget

from pyramid.httpexceptions import HTTPFound
from pyramid.view import view_config
from .models import DBSession, Page
import logging
log = logging.getLogger(__name__)


class Int(colander.Int):
    """
    Convert String returned by colander.int in to integer
    """
    def serialize(self, node, appstruct):
        result = super(Int, self).serialize(node, appstruct)
        if result is not colander.null:
            result = int(result)
        return result


class Book(colander.MappingSchema):
    """
    Map Form fields with book attributes
    """
    book_title = colander.SchemaNode(colander.String())
    book_author = colander.SchemaNode(colander.String())
    book_edition = colander.SchemaNode(colander.Int())
    book_price = colander.SchemaNode(colander.Int())
    book_quantity = colander.SchemaNode(colander.Int())


class BookStore(object):
    """
    Contains all Views of the Book Store
    """
    def __init__(self, request):
        self.request = request

    @property
    def book_form(self):
        """
        Create Form for all Fields of a Book
        :return: form of book
        """
        schema = Book()
        return deform.Form(schema, buttons=('submit',))

    @property
    def reqts(self):
        return self.book_form.get_widget_resources()

    @view_config(route_name='books_view', renderer='books_view.pt')
    def books_view(self):
        """
        List all the books of the Book Store
        :return: List of books
        """
        log.debug('In List all Books view')
        pages = DBSession.query(Page).order_by(Page.book_title)
        return dict(title='Book Store View', pages=pages)

    @view_config(route_name='book_view', renderer='book_view.pt')
    def book_view(self):
        """
        Print Details of a Specific book
        :return: Book detail page
        """
        log.debug('In Show details of Book view')
        book_id = int(self.request.matchdict['book_id'])
        page = DBSession.query(Page).filter_by(book_id=book_id).one()
        return dict(page=page)

    @view_config(route_name='book_add',
                 renderer='book_add_edit_delete.pt')
    def book_add(self):
        """
        Add a new Book to a Book Store
        :return: Detail book page
        """
        book_present = False
        form = self.book_form.render()
        if 'submit' in self.request.params:
            controls = self.request.POST.items()
            try:
                appstruct = self.book_form.validate(controls)
            except deform.ValidationFailure as error:
                return dict(form=error.render())

            # Add a new page to the database
            new_book_title = appstruct['book_title']
            new_book_author = appstruct['book_author']
            new_book_edition = appstruct['book_edition']
            new_book_price = appstruct['book_price']
            new_book_quantity = appstruct['book_quantity']
            pages = DBSession.query(Page).order_by(Page.book_title)
            for page in pages:
                if page.book_title == new_book_title and page.book_author == new_book_author:
                    page.book_quantity += new_book_quantity
                    book_present = True
                    break
            if not book_present:
                DBSession.add(Page(book_title=new_book_title,
                                   book_author=new_book_author,
                                   book_edition=new_book_edition,
                                   book_price=new_book_price,
                                   book_quantity=new_book_quantity
                                   )
                              )
            # Get the new ID and redirect
            page = DBSession.query(Page).filter_by(book_title=new_book_title,
                                                   book_author=new_book_author).one()
            new_book_id = page.book_id

            url = self.request.route_url('book_view', book_id=new_book_id)
            return HTTPFound(url)

        return dict(form=form)

    @view_config(route_name='book_edit', renderer='book_add_edit_delete.pt')
    def book_edit(self):
        """
        Edit Details of a book
        :return: new book page
        """
        book_id = int(self.request.matchdict['book_id'])
        page = DBSession.query(Page).filter_by(book_id=book_id).one()
        book_form = self.book_form

        if 'submit' in self.request.params:
            controls = self.request.POST.items()
            try:
                appstruct = book_form.validate(controls)
            except deform.ValidationFailure as error:
                return dict(page=page, form=error.render())

            # Change the content and redirect to the view
            page.book_title = appstruct['book_title']
            page.book_author = appstruct['book_author']
            page.book_edition = appstruct['book_edition']
            page.book_price = appstruct['book_price']
            page.book_quantity = appstruct['book_quantity']
            url = self.request.route_url('book_view', book_id=book_id)
            return HTTPFound(url)

        form = self.book_form.render(dict(book_id=page.book_id, book_title=page.book_title,
                                          book_author=page.book_author, book_edition=page.book_edition,
                                          book_price=page.book_price, book_quantity=page.book_quantity)
                                     )
        return dict(page=page, form=form)

    @view_config(route_name='book_delete', renderer='book_add_edit_delete.pt')
    def book_delete(self):
        """
        Delete a Book from the Book Store by using id of the book
        :return:List of remaining books
        """
        book_id = self.request.matchdict['book_id']
        page = DBSession.query(Page).filter_by(book_id=book_id).one()

        if 'submit' in self.request.params:
            controls = self.request.POST.items()
            try:
                appstruct = self.book_form.validate(controls)
            except deform.ValidationFailure as error:
                return dict(form=error.render())
            new_book_quantity = appstruct['book_quantity']
            if page.book_quantity > new_book_quantity:
                page.book_quantity -= new_book_quantity
                url = self.request.route_url('book_view', book_id=page.book_id)
                return HTTPFound(url)

            DBSession.delete(page)
            url = self.request.route_url('books_view')
            return HTTPFound(url)

        form = self.book_form.render(dict(book_id=page.book_id,
                                          book_title=page.book_title,
                                          book_author=page.book_author,
                                          book_edition=page.book_edition,
                                          book_price=page.book_price,
                                          book_quantity=page.book_quantity
                                          )
                                     )
        return dict(page=page, form=form)
