from pyramid.config import Configurator


def main(global_config, **settings):
    config = Configurator(settings=settings)
    config.include('pyramid_chameleon')
    config.add_route('add_book', '/')
    config.add_route('edit_book', '/edit_book')
    config.add_route('delete_book', '/delete_book')
    config.add_route('list_books', '/list_books')
    config.scan('.views')
    return config.make_wsgi_app()
