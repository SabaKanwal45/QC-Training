import colander
import deform.widget

from pyramid.httpexceptions import HTTPFound
from pyramid.view import view_config
from .models import DBSession, Page


class Int(colander.Int):
    def serialize(self, node, appstruct):
        result = super(Int, self).serialize(node, appstruct)
        if result is not colander.null:
            result = int(result)
        return result

class WikiPage(colander.MappingSchema):
    book_title = colander.SchemaNode(colander.String())
    book_author = colander.SchemaNode(colander.String())
    book_edition = colander.SchemaNode(colander.Int())
    book_price = colander.SchemaNode(colander.Int())
    book_quantity = colander.SchemaNode(colander.Int())


class WikiViews(object):
    def __init__(self, request):
        self.request = request

    @property
    def wiki_form(self):
        schema = WikiPage()
        return deform.Form(schema, buttons=('submit',))

    @property
    def reqts(self):
        return self.wiki_form.get_widget_resources()

    @view_config(route_name='wiki_view', renderer='wiki_view.pt')
    def wiki_view(self):
        pages = DBSession.query(Page).order_by(Page.book_title)
        return dict(title='Book Store View', pages=pages)

    @view_config(route_name='wikipage_add',
                 renderer='wikipage_addedit.pt')

    def wikipage_add(self):
        form = self.wiki_form.render()
        if 'submit' in self.request.params:
            controls = self.request.POST.items()
            try:
                appstruct = self.wiki_form.validate(controls)
            except deform.ValidationFailure as e:
                return dict(form=e.render())

            # Add a new page to the database
            new_book_title = appstruct['book_title']
            new_book_author = appstruct['book_author']
            new_book_edition = appstruct['book_edition']
            new_book_price = appstruct['book_price']
            new_book_quantity =appstruct['book_quantity']
            DBSession.add(Page(book_title=new_book_title, book_author=new_book_author,
                               book_edition=new_book_edition, book_price=new_book_price,
                               book_quantity=new_book_quantity
                               )
                          )

            # Get the new ID and redirect
            page = DBSession.query(Page).filter_by(book_title=new_book_title).one()
            new_book_id = page.book_id

            url = self.request.route_url('wikipage_view', book_id=new_book_id)
            return HTTPFound(url)

        return dict(form=form)

    @view_config(route_name='wikipage_view', renderer='wikipage_view.pt')
    def wikipage_view(self):
        book_id = int(self.request.matchdict['book_id'])
        page = DBSession.query(Page).filter_by(book_id=book_id).one()
        return dict(page=page)

    @view_config(route_name='wikipage_edit', renderer='wikipage_addedit.pt')
    def wikipage_edit(self):
        book_id = int(self.request.matchdict['book_id'])
        page = DBSession.query(Page).filter_by(book_id=book_id).one()

        wiki_form = self.wiki_form

        if 'submit' in self.request.params:
            controls = self.request.POST.items()
            try:
                appstruct = wiki_form.validate(controls)
            except deform.ValidationFailure as e:
                return dict(page=page, form=e.render())

            # Change the content and redirect to the view
            page.book_title = appstruct['book_title']
            page.book_author = appstruct['book_author']
            page.book_edition = appstruct['book_edition']
            page.book_price = appstruct['book_price']
            page.book_quantity = appstruct['book_quantity']
            url = self.request.route_url('wikipage_view', book_id=book_id)
            return HTTPFound(url)

        form = self.wiki_form.render(dict(book_id=page.book_id, book_title=page.book_title,
                                          book_author=page.book_author, book_edition=page.book_edition,
                                          book_price=page.book_price, book_quantity=page.book_quantity)
                                     )
        return dict(page=page, form=form)

    @view_config(route_name='book_delete', renderer='wikipage_addedit.pt')
    def book_delete(self):
        book_id = self.request.matchdict['book_id']
        page = DBSession.query(Page).filter_by(book_id=book_id).one()
        wiki_form = self.wiki_form

        if 'submit' in self.request.params:
            DBSession.delete(page)
            url = self.request.route_url('wiki_view')
            return HTTPFound(url)

        form = self.wiki_form.render(dict(book_id=page.book_id, book_title=page.book_title,
                                          book_author=page.book_author, book_edition=page.book_edition,
                                          book_price=page.book_price, book_quantity=page.book_quantity)
                                     )
        return dict(page=page, form=form)
